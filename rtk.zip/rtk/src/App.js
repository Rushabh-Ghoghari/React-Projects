import './App.css';
import { Provider } from 'react-redux';
import ListPokemon from './components/List';
import store from './store';

function App() {
  return (
    <div className="App">
      <Provider store={store}>
        <ListPokemon />
      </Provider>
    </div>
  );
}

export default App;
