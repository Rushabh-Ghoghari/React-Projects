// Need to use the React-specific entry point to allow generating React hooks
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'

// Define a service using a base URL and expected endpoints
export const pokemonApi = createApi({
  reducerPath: 'pokemonApi',
  baseQuery: fetchBaseQuery({ baseUrl: 'https://fakestoreapi.com/' }),
  endpoints: (builder) => ({
    getPokemonByName: builder.query({
      query: () => `products/1`,
    }),
    // updatePokemon: builder.mutation({
    //     query: ({ name, patch }) => ({
    //       url: `pokemon/${name}`,
    //       // When performing a mutation, you typically use a method of
    //       // PATCH/PUT/POST/DELETE for REST endpoints
    //       method: 'PATCH',
    //       // fetchBaseQuery automatically adds `content-type: application/json` to
    //       // the Headers and calls `JSON.stringify(patch)`
    //       body: patch,
    //     }),
    //   }),
  }),
})

// Export hooks for usage in function components, which are
// auto-generated based on the defined endpoints
export const { useGetPokemonByNameQuery } = pokemonApi