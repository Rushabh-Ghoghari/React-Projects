import React, { useEffect } from 'react'
import { useGetPokemonByNameQuery } from '../../store/api/pokemonApi'

const ListPokemon = () => {
    const [getPokemonByName,{
        data: pokemonData,
        isLoading : pokemonIsLoading,
        isSuccess: pokemonIsSuccess,
        isError: pokemonIsError,
        error: pokemonError,
      }] = useGetPokemonByNameQuery();

  useEffect(() => {
    getPokemonByName();
  }, [])
      
  console.log('pokemonData----',pokemonData);

  return (
    <div>ListPokemon</div>
  )
}

export default ListPokemon;